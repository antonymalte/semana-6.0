/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semana.pkg6.pkg0;

/**
 *
 * @author LENOVO
 */
public class Mein {
    
    private  static Interfaz formulario;
     private  static Datos paciente[];
     
     private static int contador;
     
     
    public static void main(String[] args) {
        
        formulario = new Interfaz();
        paciente = new Datos[256];
        
        for (int i = 0; i < 256; i++) {
            paciente [i]= new Datos ();
            
            
        }
        contador=0;
        formulario.setVisible(true);
        
    }
    public static void guardar(String cod,String ape,String nom,String sex,String dire,String luga,String mot,String medi,String fech) {
    paciente[contador].setCodigo(cod);
    paciente[contador].setApellido(ape); 
    paciente[contador].setNombre(nom);
    paciente[contador].setSexo(sex);       
    paciente[contador].setDireccion(dire);
    paciente[contador].setLugarAtencion(luga);    
    paciente[contador].setMotivoConsulta(mot);    
    paciente[contador].setMedico(medi);   
    paciente[contador].setFecha(fech);  
    
     contador++;
     
  
   

    
    }
     public static void buscar (String buscar) {
         for (int j=0;j<paciente.length;j++){
            if(paciente[j].getNombre().equals(buscar)){
                 formulario.cargarDatos(paciente[j]);
             }
         }
        
    }
      public static void buscar1 (String buscar1) {
         for (int j=0;j<paciente.length;j++){
            if(paciente[j].getMedico().equals(buscar1)){
                 formulario.cargarDatos1(paciente[j]);
             }
         }
        
    }
       public static void buscar2 (String buscar2) {
         for (int j=0;j<paciente.length;j++){
            if(paciente[j].getLugarAtencion().equals(buscar2)){
                 formulario.cargarDatos2(paciente[j]);
             }
         }
        
    }
     
}
